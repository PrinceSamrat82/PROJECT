# Women-Safety-App
## _Feel Safe Everywhere_


Women Safety App is user friendly application built in Android Studio using Java.
It is simple to implement and easy to understand.


## Features

- Easy to implement
- Easy to understand
- Shake detector
- Shake device to send SOS to registered mobile
- Sends Last Known Location to registered mobile

#### Prerequisites :
- Android Studio
- Basic knowledge about Firebase Authentication and Realtime database.
## Build and Run Application

###### Women Safety Application requires Android Oreo or newer version to run.
Follow this steps to get Working Project!
```
Clone this repository or download file
Extract zip if downloaded code
Open project in Android Studio
Wait while Android Studio Download gradle or required files
Hit Run Button !
```

------------

   

